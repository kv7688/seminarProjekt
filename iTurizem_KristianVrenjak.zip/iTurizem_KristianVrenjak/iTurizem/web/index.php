<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Domača stran</title>
<link rel="stylesheet" type="text/css" href="stil.css" />
</head>
<body>

<?php include "Meni.html"; ?>
<p class="uvod">Dobrodošli na spletni strani naših ekskluzivnih apartmajev na slovenski obali,
 kjer se prepletajo udobje, mir in nepozabna doživetja. Naši apartmaji Sonček,
 Barka, Oljka in Morje ponujajo edinstveno izkušnjo bivanja ob enem izmed najlepših
 delov slovenskega morja. Vsak apartma je poimenovan po elementu, ki najbolje
 odraža njegov karakter in ponuja gostom posebno vzdušje.</p>
<div class="image-container">
  <div class="image-item">
    <img id="slika1" src="Slike/1.1.jpg" alt="Slika 1" style="width: 300px; height: 200px;">
    <h3>Oljka</h3>
  </div>
  <div class="image-item">
    <img id="slika2" src="Slike/2.1.jpg" alt="Slika 2" style="width: 300px; height: 200px;">
    <h3>Sonček</h3>
  </div>
  <div class="image-item">
    <img id="slika3" src="Slike/3.1.jpg" alt="Slika 3" style="width: 300px; height: 200px;">
    <h3>Morje</h3>
  </div>
  <div class="image-item">
    <img id="slika4" src="Slike/4.1.jpg" alt="Slika 4" style="width: 300px; height: 200px;">
    <h3>Barka</h3>
  </div>
</div>

<script src="index.js"></script>

</body>
</html>
