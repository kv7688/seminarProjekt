document.addEventListener('DOMContentLoaded', function() {
    // Preverjanje prisotnosti userId in JWT žetona
    var userId = localStorage.getItem('userId');
    var jwtToken = localStorage.getItem('jwtToken');

    // Preusmeritev na prijavno stran, če nista prisotna
    if (!userId || !jwtToken) {
        window.location.href = 'prijava.php';
    } else {
        // Tukaj lahko dodate kodo, ki se izvede, če je uporabnik ustrezno prijavljen
        console.log('Uporabnik je prijavljen.');
    }
});

function prikaziObrazec(obrazecId) {
    var trenutniObrazec = document.getElementById(obrazecId);
    
    // Preverimo, če je trenutni obrazec že prikazan
    var jePrikazan = trenutniObrazec.style.display === 'block';
    
    // Skrijemo vse obrazce
    document.getElementById('obrazec1').style.display = 'none';
    document.getElementById('obrazec2').style.display = 'none';
    document.getElementById('obrazec3').style.display = 'none';
    document.getElementById('obrazec4').style.display = 'none';
    document.getElementById('obrazec5').style.display = 'none';

    // Prikaz ali skritje izbranega obrazca
    trenutniObrazec.style.display = jePrikazan ? 'none' : 'block';

    // Če prikazujemo obrazec1 in obrazec še ni bil prikazan, kličemo funkcijo prikazVsehRezervacij()
    if (obrazecId === 'obrazec1' && !jePrikazan) {
        prikazVsehRezervacij();
    }
	    // Če prikazujemo obrazec1 in obrazec še ni bil prikazan, kličemo funkcijo prikazVsehRezervacij()
    if (obrazecId === 'obrazec2' && !jePrikazan) {
        prikaziMojeRezervacije();
    }
}

	
	/**
 * Pridobi podatke iz obrazca in jih vrne v obliki JSON objekta.
 * @param  {HTMLFormControlsCollection} elements  Elementi obrazca
 * @return {Object}                               Object literal
 */
const formToJSON = elements => [].reduce.call(elements, (data, element) => 
{
	if(element.name!="")
	{
		data[element.name] = element.value;
	}
  return data;
}, {});
 
function novaRezervacija() {
    const form = document.getElementById("obrazec123");
    let data = formToJSON(form.elements); // Vsebino obrazca pretvorimo v objekt
    data['idUporabnik'] = localStorage.getItem('userId'); // Dodaj ID uporabnika iz localStorage

    var JSONdata = JSON.stringify(data, null, "  "); // Objekt pretvorimo v znakovni niz v formatu JSON
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 201) {
            document.getElementById("odgovor").innerHTML = "Dodajanje uspelo!";
        } else if (this.readyState == 4) {
            document.getElementById("odgovor").innerHTML = "Dodajanje ni uspelo: " + this.status;
        }
    };

    xmlhttp.open("POST", "/iTurizem/web/API/rezervacija.php", true);
    xmlhttp.setRequestHeader("Content-Type", "application/json");
    xmlhttp.send(JSONdata);
}



function prikazVsehRezervacij(){
	
	var httpRequest = new XMLHttpRequest();
	httpRequest.onreadystatechange = function()
	{
		if (this.readyState == 4 && this.status == 200)
		{
			try{
				var odgovorJSON = JSON.parse(this.responseText);
			}
			catch(e){
				console.log("Napaka pri razčlenjevanju podatkov");
				return;
			}
			prikaziVse(odgovorJSON);
		}
		if(this.readyState == 4 && this.status != 200)
		{
			document.getElementById("odgovor").innerHTML = "Ni uspelo: " + this.status;
		}
	};
	 
	httpRequest.open("GET", "/iTurizem/web/API/rezervacija.php", true);
	httpRequest.send();
}

function prikaziVse(odgovorJSON){
	var fragment = document.createDocumentFragment();		//zaradi učinkovitosti uporabimo fragment
	
	//za vsak element polja v JSONu ustvarimo novo vrstico v tabeli (tr)
	for (var i=0; i<odgovorJSON.length; i++) {
		var tr = document.createElement("tr");	
		
		//za vsako polje v vrstici ustvarimo novo celico v vrstici (td) ...
		for(var stolpec in odgovorJSON[i])		
		{
			var td = document.createElement("td");
			td.innerHTML=odgovorJSON[i][stolpec];	//...in vanj zapišemo prebrano vrednost
			tr.appendChild(td);						//celico dodamo v vrstico tabele
		}
		
		fragment.appendChild(tr);					//vrstico tabele dodamo v fragment
	}
	document.getElementById("tabela").innerHTML="<tr><th>ID</th><th>idApartma</th><th>datumPrihoda</th><th>datumOdhoda</th><th>idUporabnik</th></tr>";//pripravimo glavo tabele
	document.getElementById("tabela").appendChild(fragment);	//fragment dodamo v tabelo
}



function izbrisiRezervacijo() {
    var userId = localStorage.getItem('userId'); // Pridobimo userId iz localStorage
    const form = document.getElementById("obrazec12345");
    let data = formToJSON(form.elements); // Pretvorimo vsebino obrazca v objekt

    // ID rezervacije moramo pravilno vključiti v JSON podatke
    var JSONdata = JSON.stringify({ idRezervacija: data.idRezervacija }); // Pravilno pretvorimo objekt data v JSON niz
    console.log(JSONdata); // Za debug

    var xmlhttp = new XMLHttpRequest(); // Ustvarimo HTTP zahtevo

    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 204) {
            document.getElementById("odgovor1").innerHTML = "Sprememba uspela!";
        } else if (this.readyState == 4) {
            document.getElementById("odgovor1").innerHTML = "Sprememba ni uspela: " + this.status;
        }
    };

    // Določimo metodo in URL zahteve
    xmlhttp.open("DELETE", "/iTurizem/web/API/rezervacija/" + encodeURIComponent(userId), true);
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xmlhttp.send(JSONdata); // Pošljemo JSON podatke
}

function spremeniRezervacijo() {
    // Vsebino obrazca pretvorimo v objekt
    const formElements = document.getElementById("obrazec12").elements;
    const data = formToJSON(formElements);
    // Dodaj ID uporabnika iz localStorage
    data['idUporabnik'] = localStorage.getItem('userId'); 

    // Objekt pretvorimo v znakovni niz v formatu JSON
    var JSONdata = JSON.stringify(data);

    var xmlhttp = new XMLHttpRequest(); // Ustvarimo HTTP zahtevo

    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && (this.status == 200 || this.status == 204)) { // Uspešno poslano
            document.getElementById("odgovor2").innerHTML = "Sprememba uspela!";
        } else if (this.readyState == 4) { // Napaka
            document.getElementById("odgovor2").innerHTML = "Sprememba ni uspela: " + this.status;
        }
    };

    // Pravilno določimo metodo in URL zahteve z uporabo userId
    var userId = localStorage.getItem('userId'); // Ponovno pridobimo, da zagotovimo pravilnost
    xmlhttp.open("PUT", "/iTurizem/web/API/rezervacija/" + encodeURIComponent(userId), true);
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8"); // Nastavimo pravilno vsebino zahtev
    xmlhttp.send(JSONdata); // Pošljemo JSON podatke
}


function prikaziMojeRezervacije(){
	var userId = localStorage.getItem('userId'); // Pridobimo userId iz localStorage
	var httpRequest = new XMLHttpRequest();
	httpRequest.onreadystatechange = function()
	{
		if (this.readyState == 4 && this.status == 200)
		{
			try{
				var odgovorJSON = JSON.parse(this.responseText);
			}
			catch(e){
				console.log("Napaka pri razčlenjevanju podatkov");
				return;
			}
			prikaziVse2(odgovorJSON);
		}
		if(this.readyState == 4 && this.status != 200)
		{
			document.getElementById("odgovor").innerHTML = "Ni uspelo: " + this.status;
		}
	};
	 
	httpRequest.open("GET",  "/iTurizem/web/API/rezervacija/" + encodeURIComponent(userId), true);
	httpRequest.send();
}

function prikaziVse2(odgovorJSON){
	var fragment = document.createDocumentFragment();		//zaradi učinkovitosti uporabimo fragment
	
	//za vsak element polja v JSONu ustvarimo novo vrstico v tabeli (tr)
	for (var i=0; i<odgovorJSON.length; i++) {
		var tr = document.createElement("tr");	
		
		//za vsako polje v vrstici ustvarimo novo celico v vrstici (td) ...
		for(var stolpec in odgovorJSON[i])		
		{
			var td = document.createElement("td");
			td.innerHTML=odgovorJSON[i][stolpec];	//...in vanj zapišemo prebrano vrednost
			tr.appendChild(td);						//celico dodamo v vrstico tabele
		}
		
		fragment.appendChild(tr);					//vrstico tabele dodamo v fragment
	}
	document.getElementById("tabela2").innerHTML="<tr><th>ID</th><th>idApartma</th><th>datumPrihoda</th><th>datumOdhoda</th><th>idUporabnik</th></tr>";//pripravimo glavo tabele
	document.getElementById("tabela2").appendChild(fragment);	//fragment dodamo v tabelo
}
