document.addEventListener('DOMContentLoaded', function() {
    // Preverjanje prisotnosti userId in JWT žetona
    var userId = localStorage.getItem('userId');
    var jwtToken = localStorage.getItem('jwtToken');

    // Preusmeritev na prijavno stran, če nista prisotna
    if (!userId || !jwtToken) {
        window.location.href = 'prijava.php';
    } else {
        // Tukaj lahko dodate kodo, ki se izvede, če je uporabnik ustrezno prijavljen
        console.log('Uporabnik je prijavljen.');
    }
});



function prikaziObrazec(obrazecId) {
    var trenutniObrazec = document.getElementById(obrazecId);
    
    // Preverimo, če je trenutni obrazec že prikazan
    var jePrikazan = trenutniObrazec.style.display === 'block';
    
    // Skrijemo vse obrazce
    document.getElementById('obrazec1').style.display = 'none';
    document.getElementById('obrazec2').style.display = 'none';


    // Prikaz ali skritje izbranega obrazca
    trenutniObrazec.style.display = jePrikazan ? 'none' : 'block';
	
	    if (obrazecId === 'obrazec1' && !jePrikazan) {
        pokaziPodatke();
    }
}
const formToJSON = elements => [].reduce.call(elements, (data, element) => 
{
	if(element.name!="")
	{
		data[element.name] = element.value;
	}
  return data;
}, {});


function spremeniPodatke() {
    // Ustvarimo objekt data in najprej dodamo ID uporabnika iz localStorage
    var userId = localStorage.getItem('userId'); // Pravilno pridobimo userId iz localStorage
    var data = {
        'ID': userId // Tukaj dodamo userId v objekt data
    };

    // Zdaj dodamo vsebino obrazca v objekt data
    const elements = document.getElementById("obrazec12").elements;
    for (let i = 0; i < elements.length; i++) {
        let element = elements[i];
        if (element.name && element.value) {
            data[element.name] = element.value;
            console.log("dela");
        }
    }

    var JSONdata = JSON.stringify(data, null, "  "); // Objekt pretvorimo v znakovni niz v formatu JSON
    console.log(JSONdata);

    var xmlhttp = new XMLHttpRequest(); // Ustvarimo HTTP zahtevo

    xmlhttp.onreadystatechange = function() { // Določimo odziv v primeru različnih razpletov komunikacije
        if (this.readyState == 4 && this.status == 204) { // Zahteva je bila uspešno poslana, prišel je odgovor 204
            document.getElementById("odgovor2").innerHTML = "Sprememba uspela!";
        } else if (this.readyState == 4) { // Zahteva je bila uspešno poslana, prišel je odgovor, ki ni 204
            document.getElementById("odgovor2").innerHTML = "Sprememba ni uspela: " + this.status;
        }
    };

    // Določimo metodo in URL zahteve, izberemo asinhrono zahtevo (true)
    xmlhttp.open("PUT", "/iTurizem/web/API/uporabnik/" + encodeURIComponent(userId), true); // Uporabimo userId za sestavljanje URL-ja
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8"); // Dodajte ustrezno nastavitev vsebine
    xmlhttp.send(JSONdata); // Pošljemo JSON podatke
}

function pokaziPodatke() {
    var userId = localStorage.getItem('userId');
    var xmlhttp = new XMLHttpRequest(); // Ustvarimo HTTP zahtevo

    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            try {
                var odgovorJSON = JSON.parse(this.responseText);
                prikaziVse(odgovorJSON);
            } catch (e) {
                console.log("Napaka pri razčlenjevanju podatkov: " + e.message);
                return;
            }
        } else if (this.readyState == 4 && this.status != 200) {
            document.getElementById("odgovor").innerHTML = "Ni uspelo: " + this.status;
        }
    };
    
    // Določimo metodo in URL zahteve, izberemo asinhrono zahtevo (true)
    xmlhttp.open("GET", "/iTurizem/web/API/uporabnik/" + encodeURIComponent(userId), true); // Uporabimo userId za sestavljanje URL-ja
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8"); // Dodajte ustrezno nastavitev vsebine
    xmlhttp.send(); // Za GET zahtevo ni potrebno pošiljati podatkov
}


function prikaziVse(odgovorJSON){
	var fragment = document.createDocumentFragment();		//zaradi učinkovitosti uporabimo fragment
	
	//za vsak element polja v JSONu ustvarimo novo vrstico v tabeli (tr)
	for (var i=0; i<odgovorJSON.length; i++) {
		var tr = document.createElement("tr");	
		
		//za vsako polje v vrstici ustvarimo novo celico v vrstici (td) ...
		for(var stolpec in odgovorJSON[i])		
		{
			var td = document.createElement("td");
			td.innerHTML=odgovorJSON[i][stolpec];	//...in vanj zapišemo prebrano vrednost
			tr.appendChild(td);						//celico dodamo v vrstico tabele
		}
		
		fragment.appendChild(tr);					//vrstico tabele dodamo v fragment
	}
	document.getElementById("tabela").innerHTML = "<tr><th>ID</th><th>Ime</th><th>Priimek</th><th>Email</th><th>Geslo</th><th>Telefon</th></tr>";
	document.getElementById("tabela").appendChild(fragment);	//fragment dodamo v tabelo
}



