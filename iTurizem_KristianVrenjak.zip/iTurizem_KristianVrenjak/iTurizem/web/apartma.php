<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>iTurizem</title>
		<link rel="stylesheet" type="text/css" href="stil.css" />
			<script src="apartma.js"></script>
	</head>
	<body onload="prikazApartmajev()">
			<?php include"Meni.html"?>
			    <h2 id="prikaz">Opis apartmajev</h2>
			<table id="tabela"></table>
			<div id="odgovor"></div>
	</body>
</html>