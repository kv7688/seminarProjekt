<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preklop Obrazcev</title>
    <link rel="stylesheet" type="text/css" href="stil.css" />
	<script src="uporabnik.js"></script>
</head>
<body>
    <?php include "Meni.html"; ?>
    <button onclick="prikaziObrazec('obrazec1')">Moji podatki</button>
    <button onclick="prikaziObrazec('obrazec2')">Spremeni podatke</button>

	<div id="obrazec1" style="display: none;">
    <h2 id="obrazec">Moji podatki</h2>
	<table id="tabela"></table>
	</div>

	<div id="obrazec2" style="display: none;">
    <h3 id="obrazec">Spremeni podatke:</h3>
	<form id="obrazec12" onsubmit="spremeniPodatke(); return false;">
            <label for="ime">Ime:</label>
            <input type="text" id="Ime" name="Ime" required><br>
            <label for="priimek">Priimek:</label>
            <input type="text" id="Priimek" name="Priimek" required><br>
            <label for="email">E-mail:</label>
            <input type="email" id="Email" name="Email" required><br>
            <label for="geslo">Geslo:</label>
            <input type="password" id="Geslo" name="Geslo" required><br>
            <label for="telefon">Telefon:</label>
            <input type="tel" id="Telefon" name="Telefon"><br>
            <button type="submit">Pošlji</button>
        </form>
		<div id="odgovor2"></div>
    </div>
</body>
</html>
