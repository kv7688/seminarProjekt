<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centered Image</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0; /* Barva ozadja */
        }

        .centered {
            text-align: center;
        }

        .centered img {
            max-width: 80%; /* Največja širina slike */
            height: auto; /* Avtomatska višina */
        }
    </style>
</head>
<body>
    <div class="centered">
        <img src="Slike/morje.jpg" alt="Moja slika">
        <h1>Naslov pod sliko</h1>
    </div>
</body>
</html>


<body>
    <?php include "Meni.html"?>
    <div class="container">
        <div class="slika">
            <img id="slika" src="Slike/1.1.jpg" alt="Slika" width="300" height="200">
        </div>
        <h1 id="naslov">Oljka</h1>
    </div>
    <script src="index.js"></script>
</body>