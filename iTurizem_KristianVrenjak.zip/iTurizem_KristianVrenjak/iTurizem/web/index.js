


// Definiranje seznamov slik za vsak img element
var slike1 = ["Slike/1.1.jpg", "Slike/1.2.jpg", "Slike/1.3.jpg"];
var slike2 = ["Slike/2.1.jpg", "Slike/2.2.jpg", "Slike/2.3.jpg"];
var slike3 = ["Slike/3.1.jpg", "Slike/3.2.jpg", "Slike/3.3.jpg"];
var slike4 = ["Slike/4.1.jpg", "Slike/4.2.jpg", "Slike/4.3.jpg"];

var indeksi = [0, 0, 0, 0]; // Začetni indeksi za vsako skupino slik

// Funkcija za prikaz naslednje slike za določen img element
function prikaziNaslednjoSliko(slikaId, slike, indeks) {
    var imgElement = document.getElementById(slikaId);
    imgElement.src = slike[indeksi[indeks]];
    indeksi[indeks] = (indeksi[indeks] + 1) % slike.length; // Povečamo indeks
}

// Nastavimo časovnike za avtomatsko menjavo slik za vsak img element
setInterval(function() { prikaziNaslednjoSliko('slika1', slike1, 0); }, 3000);
setInterval(function() { prikaziNaslednjoSliko('slika2', slike2, 1); }, 3000);
setInterval(function() { prikaziNaslednjoSliko('slika3', slike3, 2); }, 3000);
setInterval(function() { prikaziNaslednjoSliko('slika4', slike4, 3); }, 3000);
