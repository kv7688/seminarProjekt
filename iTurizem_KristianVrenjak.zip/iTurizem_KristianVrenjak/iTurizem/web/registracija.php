<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registracija</title>
    <link rel="stylesheet" href="stil.css">
</head>
<body>
    <h3>Registracijski obrazec</h3>
    <form id="registracijskiObrazec" onsubmit="registracija(); return false;">
        <label for="ime">Ime:</label>
        <input type="text" id="ime" name="Ime" required><br><br>
        <label for="priimek">Priimek:</label>
        <input type="text" id="priimek" name="Priimek" required><br><br>
        <label for="geslo">Geslo:</label>
        <input type="password" id="geslo" name="Geslo" required><br><br>
        <label for="telefon">Telefon:</label>
        <input type="text" id="telefon" name="Telefon" required><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="Email" required><br><br>
        <input type="submit" value="Registriraj se">
    </form>
    <div id="odgovor"></div> <!-- Dodano za prikaz odgovora API-ja -->

    <script>
    const formToJSON = elements => [].reduce.call(elements, (data, element) => {
        if(element.name!="") {
            data[element.name] = element.value;
        }
        return data;
    }, {});

    function registracija() {
        const form = document.getElementById("registracijskiObrazec");
        let data = formToJSON(form.elements); // Vsebino obrazca pretvorimo v objekt
        var JSONdata = JSON.stringify(data); // Objekt pretvorimo v znakovni niz v formatu JSON
        var xmlhttp = new XMLHttpRequest();

        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 201) {
                // Registracija uspešna, preusmeritev na prijava.php
                window.location.href = 'prijava.php';
            } else if (this.readyState == 4) {
                document.getElementById("odgovor").innerHTML = "Registracija ni uspela: " + this.status;
            }
        };

        xmlhttp.open("POST", "/iTurizem/web/API/uporabnik.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSONdata);
    }
    </script>
</body>
</html>
