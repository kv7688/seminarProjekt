<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rezervacija</title>
	<link rel="stylesheet" type="text/css" href="stil.css" />
	<script src="rezervacija.js"></script>
</head>
<body>
<?php include"Meni.html"?>
<button onclick="prikaziObrazec('obrazec1')">Vse rezervacije</button>
<button onclick="prikaziObrazec('obrazec2')">Moje rezervacije</button>
<button onclick="prikaziObrazec('obrazec3')">Nova rezervacija</button>
<button onclick="prikaziObrazec('obrazec4')">Spremeni rezervacijo</button>
<button onclick="prikaziObrazec('obrazec5')">Izbriši rezervacijo</button>


<div id="obrazec1" style="display: none;">
    <h2 id="obrazec">Vse rezervacije</h2>
	<table id="tabela"></table>


</div>

<div id="obrazec2" style="display: none;">
    <h2 id="obrazec">Moje rezervacije</h2>
	<table id="tabela2"></table>
</div>
	
<div id="obrazec3" style="display: none;">
    <h3 id="obrazec">Nova rezervacija</h3>
	<form id="obrazec123" onsubmit="novaRezervacija(); return false;">
    <label for="idApartma">Izberite apartma:</label>
    <select id="idApartma" name="idApartma">
        <option value="1">1-Oljka</option>
        <option value="2">2-Sonček</option>
        <option value="3">3-Morje</option>
        <option value="4">4-Barka</option>
    </select>
    <br>

    <label for="datumPrihoda">Datum prihoda:</label>
    <input type="date" id="datumPrihoda" name="datumPrihoda">
    <br>

    <label for="datumOdhoda">Datum odhoda:</label>
    <input type="date" id="datumOdhoda" name="datumOdhoda">
    <br>



    <br>
	<br>
	
        <div class="form-group">
            <button type="submit">Rezerviraj</button>
        </div>

</form>
<div id="odgovor"></div>
</div>
	
<div id="obrazec4" style="display: none;">
    <h3 id="obrazec">Spremeni rezervacijo</h3>
	<form id="obrazec12" onsubmit="spremeniRezervacijo(); return false;">
	<label for="ID">ID Rezervacije:</label>
    <input type="number" id="idSpremeni" name="idRezervacija" required>
    <label for="apartmaIzbira">Izberite apartma:</label>
    <select id="idApartma" name="idApartma">
        <option value="1">Oljka</option>
        <option value="2">Sonček</option>
        <option value="3">Morje</option>
        <option value="4">Barka</option>
    </select>
    <br>

    <label for="datumPrihoda">Datum prihoda:</label>
    <input type="date" id="datumPrihoda" name="datumPrihoda" required>
    <br>

    <label for="datumOdhoda">Datum odhoda:</label>
    <input type="date" id="datumOdhoda" name="datumOdhoda" required>
    <br>
	<br>
       <div class="form-group">
            <button type="submit">Spremeni</button>
        </div>
</form>
<div id="odgovor2"></div>
</div>

<div id="obrazec5" style="display: none;">
    <h3 id="obrazec">Izbriši rezervacijo</h3>
	<form id="obrazec12345" onsubmit="izbrisiRezervacijo(); return false;">
    <label for="idRezervacija">ID Rezervacije:</label>
    <input type="number" id="idBrisanje" name="idRezervacija" required>
    <br>
	<br>
       <div class="form-group">
            <button type="submit">Izbriši</button>
        </div>
	<div id="odgovor1"></div>
</form>
</div>


</body>
</html>
