<?php
$DEBUG = true;

include("osnova.php"); // Vključitev 'orodij'

$zbirka = dbConnect(); // Pridobitev povezave s podatkovno zbirko

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Dovolimo dostop izven trenutne domene (CORS)
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.

switch ($_SERVER["REQUEST_METHOD"]) {
    case 'GET':
        prikaziApartmaje();
        break;
    case 'PUT':
        if (!empty($_GET["idApartma"])) {
            spremeniCeno($_GET["idApartma"]);
        } else {
            http_response_code(400); // Bad Request
        }
        break;
    default:
        http_response_code(405); // Method Not Allowed
        break;
}

function prikaziApartmaje()
{
    global $zbirka, $DEBUG;

    $poizvedba = "CALL prikaziApartma()";;
    $rezultat = mysqli_query($zbirka, $poizvedba);

    if ($rezultat) {
        $apartmaji = array();

        while ($vrstica = mysqli_fetch_assoc($rezultat)) {
            $apartmaji[] = $vrstica;
        }

        http_response_code(200); // OK
        echo json_encode($apartmaji);
    } else {
        http_response_code(500); // Internal Server Error

        if ($DEBUG) {
            pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
        }
    }
}

function spremeniCeno($idApartma)
{
	global $zbirka, $DEBUG;
	
	$idApartma = mysqli_escape_string($zbirka, $idApartma);
	
	$podatki = json_decode(file_get_contents("php://input"),true);
		
	if(apartmaObstaja($idApartma))
	{
		if(isset($podatki["Cena"]))
		{
			
			$Cena = mysqli_escape_string($zbirka, $podatki["Cena"]);
			
	
			$poizvedba = "CALL spremeniCeno($idApartma, $Cena)";
			
			if(mysqli_query($zbirka, $poizvedba))
			{
				http_response_code(204);	//OK with no content
			}
			else
			{
				http_response_code(500);	// Internal Server Error (ni nujno vedno streznik kriv!)
				
				if($DEBUG)	//Pozor: vračanje podatkov o napaki na strežniku je varnostno tveganje!
				{
					pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
				}
			}
		}
		else
		{
			http_response_code(400);	// Bad Request
		}
	}
	else
	{
		http_response_code(404);	// Not Found
	}
}
?>
