<?php
$DEBUG = true;

include("osnova.php"); 			// Vključitev 'orodij'

$zbirka = dbConnect();			//Pridobitev povezave s podatkovno zbirko

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Dovolimo dostop izven trenutne domene (CORS)
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.

switch ($_SERVER["REQUEST_METHOD"]) {
    case 'GET':
        if (!empty($_GET["idUporabnik"])) {
            prikaziMojeRezervacije($_GET["idUporabnik"]);
        } else {
            prikaziVseRezervacije();	
        }
        break;
    
    case 'POST':
        dodajRezervacijo();
        break;
    
    case 'PUT':
        if (!empty($_GET["idUporabnik"])) {
            spremeniRezervacijo($_GET["idUporabnik"]);
        } else {
            http_response_code(400);    // Bad Request
        }
        break;
    
    case 'DELETE':
		 if (!empty($_GET["idUporabnik"])) {
            izbrisiRezervacijo($_GET["idUporabnik"]);
        }
		else {
            http_response_code(400);    // Bad Request
        }
        break;

    default:
        http_response_code(405);    // Method Not Allowed
        break;
}

mysqli_close($zbirka);	

// Sprostimo povezavo z zbirko



function prikaziVseRezervacije() {
    global $zbirka, $DEBUG;

    $poizvedba = "CALL prikaziVseRezervacije()";
    $rezultat = mysqli_query($zbirka, $poizvedba);

    if ($rezultat) {
        $rezervacije = array();

        while ($vrstica = mysqli_fetch_assoc($rezultat)) {
            $rezervacije[] = $vrstica;
        }

        http_response_code(200);  // OK
        echo json_encode($rezervacije);
    } else {
        http_response_code(500);  // Internal Server Error

        if ($DEBUG) {
            pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
        }
    }
}

function prikaziMojeRezervacije($idUporabnik)
{
    global $zbirka;
    $idUporabnik = mysqli_escape_string($zbirka, $idUporabnik);
    $odgovor = array();
    if (uporabnik_obstaja($idUporabnik)) {
        $poizvedba = "CALL prikaziMojeRezervacije('$idUporabnik')";

        $result = mysqli_query($zbirka, $poizvedba);

        if ($result) {
            while ($vrstica = mysqli_fetch_assoc($result)) {
                $odgovor[] = $vrstica;
            }

            http_response_code(200);    // OK
            echo json_encode($odgovor);
        } else {
            http_response_code(500);    // Internal Server Error

            if ($DEBUG) {
                pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
            }
        }
    } else {
        http_response_code(404);    // Not Found
        echo "Uporabnik ne obstaja";
    }
}



function dodajRezervacijo()
{
    global $zbirka, $DEBUG;

    $podatki = json_decode(file_get_contents('php://input'), true);

    if (isset($podatki["idApartma"], $podatki["datumPrihoda"], $podatki["datumOdhoda"], $podatki["idUporabnik"])) {
        // Preveri, ali uporabnik obstaja
        if (uporabnik_obstaja($podatki["idUporabnik"])) {
            $idApartma = mysqli_escape_string($zbirka, $podatki["idApartma"]);
            $datumPrihoda = mysqli_escape_string($zbirka, $podatki["datumPrihoda"]);
            $datumOdhoda = mysqli_escape_string($zbirka, $podatki["datumOdhoda"]);
            $idUporabnik = mysqli_escape_string($zbirka, $podatki["idUporabnik"]);

            $datumPrihodaP = $datumPrihoda;
            $datumOdhodaP = $datumOdhoda;

            // Uporabi samo idApartma za preverjanje zasedenosti obdobja
            $preverba = preveriZasedenostObdobja($datumPrihodaP, $datumOdhodaP, $idApartma);

            if ($preverba) {
                $poizvedba = "CALL dodajRezervacijo('$idApartma', '$datumPrihodaP', '$datumOdhodaP', '$idUporabnik')";
                if (mysqli_query($zbirka, $poizvedba)) {
                    http_response_code(201);    // Created
                    // ne pošljemo URL-ja do vpisane igre, ker ne omogočamo vpogleda v posamezno igro
                } else {
                    http_response_code(500);    // Internal Server Error

                    if ($DEBUG) {
                        pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
                    }
                }
            } else {
                echo "Termin je žal zaseden";
                return;
            }
        } else {
            http_response_code(409);    // Conflict (uporabnik ne obstaja)
            pripravi_odgovor_napaka("Uporabnik ne obstaja!", 567);
        }
    } else {
        http_response_code(400);    // Bad Request
        echo "Manjkajoči podatki";
    }
}



function spremeniRezervacijo($idUporabnik)
{
	global $zbirka, $DEBUG;

    $podatki = json_decode(file_get_contents('php://input'), true);	

    if (isset($podatki["idRezervacija"],$podatki["idApartma"], $podatki["datumPrihoda"], $podatki["datumOdhoda"])) {
		$idRezervacija = mysqli_escape_string($zbirka, $podatki["idRezervacija"]);
        $idApartma = mysqli_escape_string($zbirka, $podatki["idApartma"]);
        $datumPrihoda = mysqli_escape_string($zbirka, $podatki["datumPrihoda"]);
        $datumOdhoda = mysqli_escape_string($zbirka, $podatki["datumOdhoda"]);

        $datumPrihodaP = $datumPrihoda;
        $datumOdhodaP =  $datumOdhoda;

        if (preveriRezervacijo($idRezervacija)) {
			if(preveriZasedenostObdobja($datumPrihodaP, $datumOdhodaP, $idApartma)){
            // Dodajte manjkajoče spremenljivke $datumPrihodaP in $datumOdhodaP
            $poizvedba = "CALL spremeniRezervacijo('$idRezervacija', '$idApartma', '$datumPrihodaP', '$datumOdhodaP', '$idUporabnik')";

            if (mysqli_query($zbirka, $poizvedba)) {
                http_response_code(204);    // OK with no content
            } else {
                http_response_code(500);    // Internal Server Error

                if ($DEBUG) {
                    pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
                }
            }
		} else {
            http_response_code(404);    // Not Found
            echo "Termini se prekrivajo";
        }
        } else {
            http_response_code(404);    // Not Found
            echo "Rezervacija ne obstaja";
        }
    } else {
        http_response_code(400);    // Bad Request
        echo "Manjkajoči podatki";
    }
}



function izbrisiRezervacijo($idUporabnik)
{
    global $zbirka, $DEBUG; // Predvidevam, da so $podatki globalni ali pa so definirani nekje prej
    $podatki = json_decode(file_get_contents("php://input"), true);


    if (isset($podatki["idRezervacija"])) {
        $idRezervacija = mysqli_escape_string($zbirka, $podatki["idRezervacija"]);
		$idUporabnik = mysqli_escape_string($zbirka, $idUporabnik);
        if (preveriRezervacijo($idRezervacija)) {
            if (uporabnikImaRezervacijo($idUporabnik, $idRezervacija)) {
                $poizvedba = "CALL izbrisiRezervacijo($idRezervacija)";

                if (mysqli_query($zbirka, $poizvedba)) {
                    http_response_code(204); // OK with no content
                } else {
                    http_response_code(500); // Internal Server Error

                    if ($DEBUG) {
                        // pripravi_odgovor_napaka mora biti definirana funkcija, tukaj sem predpostavil njeno obstojnost
                        pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
                    }
                }
            } else {
                http_response_code(404);
                echo "Uporabnik ni lastnik rezervacije";
            }
        } else {
            http_response_code(404); // Not Found
            echo "Rezervacija ne obstaja";
        }
    } else {
        http_response_code(400); // Bad Request
        echo "Manjkajoči podatki";
    }
}



?>