<?php

/**
 * Funkcija vzpostavi povezavo z zbirko podatkov na proceduralni način
 *
 * @return $conn objekt, ki predstavlja povezavo z izbrano podatkovno zbirko
 */
include("povezava.php");

/**
 * Funkcija pripravi odgovor v obliki JSON v primeru napake
 *
 * @param $vsebina Znakovni niz, ki opisuje napako
 */
function pripravi_odgovor_napaka($vsebina, $koda)
{
	$odgovor=array(
		'status' => $koda,
		'error_message'=>$vsebina
	);
	echo json_encode($odgovor);
}

/**
 * Funkcija preveri, če podan igralec obstaja v podatkovni zbirki
 *
 * @param $vzdevek Vzdevek igralca
 * @return true, če igralec obstaja, v nasprotnem primeru false
 */
function uporabnik_obstaja($ID)
{	
	global $zbirka;
	$ID=mysqli_escape_string($zbirka, $ID);
	
	$poizvedba="SELECT * FROM uporabniki WHERE ID='$ID'";
	
	if(mysqli_num_rows(mysqli_query($zbirka, $poizvedba)) > 0)
	{
		return true;
	}
	else
	{
		return false;
	}	
}
function uporabnikImaRezervacijo($idUporabnik, $idRezervacija)
{
    global $zbirka;
    $idUporabnik = mysqli_escape_string($zbirka, $idUporabnik);
    $idRezervacija = mysqli_escape_string($zbirka, $idRezervacija);
    
    $poizvedba = "SELECT * FROM rezervacija WHERE idUporabnik = '$idUporabnik' AND ID = '$idRezervacija'";
    
    $rezultat = mysqli_query($zbirka, $poizvedba);
    if(mysqli_num_rows($rezultat) > 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}


function apartmaObstaja($ID)
{	
	global $zbirka;
	$ID=mysqli_escape_string($zbirka, $ID);
	
	$poizvedba="SELECT * FROM apartma WHERE ID='$ID'";
	
	if(mysqli_num_rows(mysqli_query($zbirka, $poizvedba)) > 0)
	{
		return true;
	}
	else
	{
		return false;
	}	
}


function preveriRezervacijo($idRezervacija)
{
    global $zbirka;
		
    // Preverjanje ali rezervacija z določenim idRezervacija obstaja
    $poizvedba = "SELECT * FROM rezervacija WHERE ID = '$idRezervacija'";
    $rezultat = mysqli_query($zbirka, $poizvedba);

    if ($rezultat && mysqli_num_rows($rezultat) > 0) {
        return true; // Rezervacija obstaja
    } else {
        return false; // Rezervacija ne obstaja
    }
}





function preveriZasedenostObdobja($datumPrihoda, $datumOdhoda, $idApartma)
{
    global $zbirka;

    // Preverjanje zasedenosti obdobja v tabeli rezervacij za določen apartma
    if ($datumPrihoda >= $datumOdhoda) {
        return false; // Datum odhoda mora biti po datumu prihoda
    }

    $poizvedba = "SELECT * FROM rezervacija WHERE idApartma = '$idApartma' AND ((datumPrihoda BETWEEN '$datumPrihoda' AND '$datumOdhoda') OR (datumOdhoda BETWEEN '$datumPrihoda' AND '$datumOdhoda'))";
    $rezultat = mysqli_query($zbirka, $poizvedba);

    if (mysqli_num_rows($rezultat) > 0) {
        return false; // Obdobje je že zasedeno
    } else {
        return true; // Obdobje je prosto
    }
}




/**
 * Funkcija pripravi URL podanega vira
 *
 * @param $vir Ime vira
 * @return $url URL podanega vira
 */
function URL_vira($vir)
{
	if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
	{
		$url = "https"; 
	}
	else
	{
		$url = "http"; 
	}
	$url .= "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . $vir;
	
	return $url; 
}


function spremeniDatum($datum)
{
    $datumJ = DateTime::createFromFormat('j.n.Y', $datum);
    $datumP = $datumJ->format('Y-m-d');
    
    return $datumP;
}
?>