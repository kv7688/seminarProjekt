<?php
$DEBUG = true;

include("osnova.php"); 			// Vključitev 'orodij'

$zbirka = dbConnect();			//Pridobitev povezave s podatkovno zbirko

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');	// Dovolimo dostop izven trenutne domene (CORS)
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.


require 'C:\xampp\htdocs\iTurizem\vendor\autoload.php';
// Vključitev avtomatskega nalagalnika Composer
use Firebase\JWT\JWT;

switch($_SERVER["REQUEST_METHOD"])			//glede na HTTP metodo izvedemo ustrezno dejanje nad virom
{

	
	case 'POST':
			prijava();
		break;


	default:
		http_response_code(405);	//Method Not Allowed
		break;
}

function prijava() {
    global $zbirka;

    $podatki = json_decode(file_get_contents("php://input"), true);
    
    if(isset($podatki["Email"], $podatki["Geslo"])) {
        $Email = mysqli_real_escape_string($zbirka, $podatki["Email"]);
        $Geslo = $podatki["Geslo"]; // Geslo, ki ga je vnesel uporabnik
        
        // Varnejša SQL poizvedba z uporabo pripravljene izjave
        $poizvedba = "SELECT ID, Geslo FROM uporabniki WHERE Email = ?";
        if ($stmt = mysqli_prepare($zbirka, $poizvedba)) {
            mysqli_stmt_bind_param($stmt, "s", $Email);
            mysqli_stmt_execute($stmt);
            $rezultat = mysqli_stmt_get_result($stmt);

            if($uporabnik = mysqli_fetch_assoc($rezultat)) {
                // Testni izpis ID-ja uporabnika in gesla (NEUPORABNO V PRODUKCIJI)


                // Preverjanje, če se geslo ujema
                if(password_verify($Geslo, $uporabnik['Geslo'])) {
                    // Geslo se ujema, generiranje JWT
                    //echo json_encode(["error" => "Prijava uspela"]);
					//header('Location: ../index.php');


                    $tajniKljuc = 'vaš_skriti_ključ';
                    $payload = [
                        "iat" => time(),
                        "exp" => time() + 3600, // Veljavnost 1 uro
                        "data" => ["userId" => $uporabnik['ID']]
                    ];
                    $jwt = JWT::encode($payload, $tajniKljuc, 'HS256');
                    echo json_encode(["jwt" => $jwt,"userId"=>$uporabnik['ID']]);
				
					

                } else {
                    // Geslo se ne ujema
                    http_response_code(401); // Unauthorized
                    echo json_encode(["error" => "Napačne poverilnice"]);
                }
            } else {
                // E-pošta ne obstaja v bazi
                http_response_code(404); // Not Found
                echo json_encode(["error" => "Uporabnik ni najden"]);
            }
        } else {
            // Napaka pri izvajanju poizvedbe
            http_response_code(500); // Internal Server Error
            echo json_encode(["error" => "Prišlo je do napake pri obdelavi zahteve."]);
        }
    } else {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "Manjkajoči podatki"]);
    }
}
