<?php
function dbConnect(){
	include "poverilnica.php";

	// Ustvarimo povezavo do podatkovne zbirke
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	mysqli_set_charset($conn,"utf8");
	
	// Preverimo uspeh povezave
	if (mysqli_connect_errno()) {
		return "Povezovanje s podatkovnim strežnikom ni uspelo: " . mysqli_connect_error();
	} 	
	return $conn;
}


?>

