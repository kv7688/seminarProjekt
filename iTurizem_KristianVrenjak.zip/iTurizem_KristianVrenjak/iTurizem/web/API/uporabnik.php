<?php
$DEBUG = true;

include("osnova.php"); 			// Vključitev 'orodij'

$zbirka = dbConnect();			//Pridobitev povezave s podatkovno zbirko

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');	// Dovolimo dostop izven trenutne domene (CORS)
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.


switch($_SERVER["REQUEST_METHOD"])			//glede na HTTP metodo izvedemo ustrezno dejanje nad virom
{
	case 'GET':
		podatkiUporabnika($_GET["idUporabnik"]);
		break;
	
	case 'POST':
			dodajUporabnika();
		break;

	case 'PUT':
			spremeniUporabnika($_GET["idUporabnik"]);
		break;
	default:
		http_response_code(405);	//Method Not Allowed
		break;
}

mysqli_close($zbirka);	

function spremeniUporabnika($idUporabnik)
{
	global $zbirka, $DEBUG;
	
	$idUporabnik = mysqli_escape_string($zbirka, $idUporabnik);
	
	$podatki = json_decode(file_get_contents("php://input"),true);
		
	if(uporabnik_obstaja($idUporabnik))
	{
		if(isset($podatki["Ime"], $podatki["Priimek"], $podatki["Geslo"], $podatki["Telefon"],$podatki["Email"]))
		{
			
			$Ime = mysqli_escape_string($zbirka, $podatki["Ime"]);
			$Priimek = mysqli_escape_string($zbirka, $podatki["Priimek"]);
			$Geslo = password_hash(mysqli_escape_string($zbirka, $podatki["Geslo"]), PASSWORD_DEFAULT);
			$Telefon = mysqli_escape_string($zbirka, $podatki["Telefon"]);
			$Email = mysqli_escape_string($zbirka, $podatki["Email"]);
	
			$poizvedba = "CALL posodobiUporabnika($idUporabnik, '$Ime', '$Priimek', '$Geslo', '$Telefon', '$Email')";
			
			if(mysqli_query($zbirka, $poizvedba))
			{
				http_response_code(204);	//OK with no content
			}
			else
			{
				http_response_code(500);	// Internal Server Error (ni nujno vedno streznik kriv!)
				
				if($DEBUG)	//Pozor: vračanje podatkov o napaki na strežniku je varnostno tveganje!
				{
					pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
				}
			}
		}
		else
		{
			http_response_code(400);	// Bad Request
		}
	}
	else
	{
		http_response_code(404);	// Not Found
	}
}

function dodajUporabnika()
{
    global $zbirka, $DEBUG;

    $podatki = json_decode(file_get_contents("php://input"), true);

    if (isset($podatki["Ime"], $podatki["Priimek"], $podatki["Geslo"], $podatki["Telefon"], $podatki["Email"])) {
        $Ime = mysqli_escape_string($zbirka, $podatki["Ime"]);
        $Priimek = mysqli_escape_string($zbirka, $podatki["Priimek"]);
        $Geslo = password_hash(mysqli_escape_string($zbirka, $podatki["Geslo"]), PASSWORD_DEFAULT);
        $Telefon = mysqli_escape_string($zbirka, $podatki["Telefon"]);
        $Email = mysqli_escape_string($zbirka, $podatki["Email"]);

        $poizvedba = "CALL dodajUporabnika('$Ime', '$Priimek', '$Geslo', '$Telefon', '$Email')";

        if (mysqli_query($zbirka, $poizvedba)) {
            http_response_code(201);    // Created
        } else {
            http_response_code(500);    // Internal Server Error

            if ($DEBUG) {
                pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
            }
        }
    } elseif (isset($podatki["Email"])) {
        http_response_code(409);    // Conflict
        pripravi_odgovor_napaka("Uporabnik že obstaja!", 567);
    } else {
        http_response_code(400);    // Bad Request
    }
}

function podatkiUporabnika($idUporabnik)
{
    global $zbirka;
    $idUporabnik = mysqli_escape_string($zbirka, $idUporabnik);
    $odgovor = array();
    if (uporabnik_obstaja($idUporabnik)) {
        $poizvedba = "CALL prikaziUporabnika('$idUporabnik')";

        $result = mysqli_query($zbirka, $poizvedba);

        if ($result) {
            while ($vrstica = mysqli_fetch_assoc($result)) {
                $odgovor[] = $vrstica;
            }

            http_response_code(200);    // OK
            echo json_encode($odgovor);
        } else {
            http_response_code(500);    // Internal Server Error

            if ($DEBUG) {
                pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
            }
        }
    } else {
        http_response_code(404);    // Not Found
        echo "Uporabnik ne obstaja";
    }
}

?>