<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prijavni obrazec</title>
    <link rel="stylesheet" type="text/css" href="stil.css" />
</head>
<body>
<h3>Prijava</h3>
<form id="prijavaobrazec">
    <label for="Email">Email:</label>
    <input type="email" id="Email" name="Email" required>
    <br>
    <label for="Geslo">Geslo:</label>
    <input type="password" id="Geslo" name="Geslo" required>
    <br>
    <input type="button" value="Prijava" onclick="prijava()">
    <div id="odgovor1"></div>
</form>

<script>
const formToJSON = elements => [].reduce.call(elements, (data, element) => {
    if(element.name != "") {
        data[element.name] = element.value;
    }
    return data;
}, {});

function prijava() {
    const form = document.getElementById("prijavaobrazec");
    const data = formToJSON(form.elements); // Vsebino obrazca pretvorimo v objekt
    const JSONdata = JSON.stringify(data); // Objekt pretvorimo v znakovni niz v formatu JSON

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var odgovorJSON = JSON.parse(this.responseText);
			console.log(odgovorJSON)
            if(odgovorJSON.jwt && odgovorJSON.userId) {
                // Shranjevanje JWT in ID uporabnika v localStorage
                localStorage.setItem('jwtToken', odgovorJSON.jwt);
                localStorage.setItem('userId', odgovorJSON.userId);
                // Preusmeritev na domačo stran ali drugo stran po uspešni prijavi
                window.location.href = "index.php";
            } else {
                document.getElementById("odgovor1").innerHTML = "Prijava ni uspela: Podatki niso pravilni.";
            }
        } else if (this.readyState == 4) {
            document.getElementById("odgovor1").innerHTML = "Prijava ni uspela: " + this.status;
        }
    };

    xmlhttp.open("POST", "/iTurizem/web/API/prijava.php", true);
    xmlhttp.setRequestHeader("Content-Type", "application/json");
    xmlhttp.send(JSONdata);
}
</script>
</body>
</html>


