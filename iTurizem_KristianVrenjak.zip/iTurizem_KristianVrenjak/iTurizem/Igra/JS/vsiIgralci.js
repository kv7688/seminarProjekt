function vsiIgralci(){
		
	var httpRequest = new XMLHttpRequest();
	httpRequest.onreadystatechange = function()
	{
		if (this.readyState == 4 && this.status == 200)
		{
			try{
				var odgovorJSON = JSON.parse(this.responseText);
			}
			catch(e){
				console.log("Napaka pri razčlenjevanju podatkov");
				return;
			}
			prikazi(odgovorJSON);
		}
	};
	 
	httpRequest.open("GET", "/igraAPI/igralci", true);
	httpRequest.send();
}

function prikazi(odgovorJSON){
	var fragment = document.createDocumentFragment();		//zaradi učinkovitosti uporabimo fragment
	
	//za vsak element polja v JSONu ustvarimo novo vrstico v tabeli (tr)
	for (var i=0; i<odgovorJSON.length; i++) {
		var tr = document.createElement("tr");
		
		//za vsak stolpec v vrstici ustvarimo novo celico (td) ...
		for(var stolpec in odgovorJSON[i]){
			var td = document.createElement("td");
			td.innerHTML=odgovorJSON[i][stolpec];		//...in vanjo zapišemo prebrano vrednost
			tr.appendChild(td);						//celico dodamo v vrstico tabele
		}
		fragment.appendChild(tr);					//vrstico tabele dodamo v fragment
	}
	document.getElementById("tabela").appendChild(fragment);	//fragment dodamo v tabelo
}