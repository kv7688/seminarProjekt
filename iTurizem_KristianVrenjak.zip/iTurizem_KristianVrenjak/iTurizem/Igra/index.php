<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Igra - Prva stran</title>
		<link rel="stylesheet" type="text/css" href="stil.css" />
	</head>
	<body>
		<div class="center">
			<?php include"Meni.html"?>
			<p>Prva stran</p>
			<img class="content" src="slike/igra1.png">
		</div>
	</body>
</html>