package si.uni_lj.fe.seminar.igra;

import java.util.Random;
import android.content.Context;
import android.content.Intent;
import android.media.SoundPool;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    private final int OSNOVNA_PERIODA_PREMIKANJA_V_MS = 1000;
    private final int TRAJANJE_IGRE_V_MS = 20000;

    // konstante, ki identificirajo postavke v menijih:
    private final int MENU_NOVA_IGRA = 0;
    private final int MENU_TEZAVNOST = 1;
    private final int MENU_TEZAVNOST_LAHKA = 10;
    private final int MENU_TEZAVNOST_SREDNJA = 20;
    private final int MENU_TEZAVNOST_TEZKA = 30;
    private final int MENU_LESTVICA = 2;
    private final int MENU_IZHOD = -1;

    // spremenljivke, ki jih potrebujemo v notranjih razredih (zato niso privatne)
    SoundPool sp; // predvajalnik zvoka
    int[] soundId = new int[1];

    int periodaPremika; // perioda premikanja, ki je trenutno v veljavi
    private Random generator = new Random(); // generator naključnih števil
    long zacetniCas; // čas, ko se je začela nova igra

    // spremenljivke za ponavljajoča opravila (premikanje balona in štetje časa)
    private Handler upravljalnikGibanjaBaloncka = new Handler();
    private Runnable gibanjeBaloncka;
    private Handler upravljalnikCasovnika = new Handler();
    private Runnable casovnik;

    // spremenljivke, ki določajo parametre igre
    private String vzdevek;
    private int stevecZadetkov = 0;
    private int tezavnost = 1;

    // reference na gradnike uporabniškega vmesnika:
    private ImageView baloncek;
    private TextView napis;
    private ConstraintLayout zaslonAplikacije;

    // referenca na glavno aktivnost (za uporabo v notranjih razredih)
    MainActivity mainActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mainActivity = this;

        init();
        //zacniIgro();
    }

    private void init() {
        // ustvarimo objekt medijskega predvajalnika in ga nastavimo
        sp = new SoundPool.Builder().setMaxStreams(1).build();

        // naložimo posnetek
        int soundIds[] = new int[1];
        soundId[0] = sp.load(this, R.raw.balloon, 1);

        // gradnike graficnega vmesnika shranimo v spremenljivke
        baloncek = findViewById(R.id.baloncek);
        napis = findViewById(R.id.napis);
        zaslonAplikacije = findViewById(R.id.zaslonAplikacije);

        // sliko shranimo v spremenljivko in jo postavimo na zaslon
        Bitmap mBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.rdeci);
        baloncek.setImageBitmap(mBitmap);

        //iz datoteke strings.xml preberemo vpisan vzdevek
        vzdevek = getResources().getString(R.string.vzdevek);
    }

    private void zacniIgro(){
        baloncek.setEnabled(true); // "aktiviramo" pogled s sliko (lahko se ga dotikamo)

        baloncek.setOnClickListener(v->{
            stevecZadetkov++;
            sp.play(soundId[0], 1, 1, 1, 0, 1.0f);
            baloncek.animate().scaleX(0).scaleY(0).setDuration(100).start();
        });

        zacniPremikanje();
        zacniOdstevanje();
    }

    private void zacniPremikanje(){
        stevecZadetkov = 0; // stevec zadetkov postavimo na nic

        // na podlagi tezavnosti igre izracunamo cas med premiki baloncka
        periodaPremika = (int) (OSNOVNA_PERIODA_PREMIKANJA_V_MS / (0.5 + 0.5 * tezavnost));

        // izpisemo rezultat na pogled za izpis teksta
        napis.setText("Stevilo zadetkov:" + stevecZadetkov);

        // definiramo opravilo, ki bo skrbelo za neprestano premikanje baloncka v skladu z izracunanimi parametri
        gibanjeBaloncka = new Runnable() {
            @Override
            public void run() {
                ConstraintLayout.LayoutParams lp = (ConstraintLayout.LayoutParams) baloncek.getLayoutParams();

                int x = Math.round(generator.nextFloat() * (zaslonAplikacije.getWidth() - baloncek.getWidth() - 2 * lp.leftMargin));
                int y = Math.round(generator.nextFloat() * (zaslonAplikacije.getHeight() - baloncek.getHeight() - 2 * napis.getHeight()));

                baloncek.animate().scaleX(1).scaleY(1);
                baloncek.animate().setDuration(100).translationX(x).translationY(y);

                // zakasnimo naslednji premik za periodo, ki smo jo izracunali v metodi zacniPremikanje
                upravljalnikGibanjaBaloncka.postDelayed(this, periodaPremika);
            }
        };

        // sprozimo zgoraj definirano opravilo
        upravljalnikGibanjaBaloncka.removeCallbacks(gibanjeBaloncka);
        upravljalnikGibanjaBaloncka.postDelayed(gibanjeBaloncka, 100);
    }

    private void zacniOdstevanje(){
        zacetniCas = System.currentTimeMillis(); // ugotovimo začetni čas

        // definiramo opravilo, ki bo skrbelo za odštevanje časa
        casovnik = new Runnable() {
            @Override
            public void run() {
                long trajanjeIgre = System.currentTimeMillis() - zacetniCas;  // izračunamo trajanje igre

                // če se čas še ni iztekel, samo izpišemo na tekstovni pogled čas trajanja igre in rezultat
                if (trajanjeIgre < TRAJANJE_IGRE_V_MS) {
                    napis.setText(getResources().getString(R.string.napis_preostali_cas) + " " + Math.round((TRAJANJE_IGRE_V_MS - trajanjeIgre) / 1000)
                            + "  " + getResources().getString(R.string.napis_stevilo_zadetkov) + " " + stevecZadetkov);
                    upravljalnikCasovnika.postDelayed(this, 50);
                    // v nasprotnem primeru uporabniku prikažemo dialog z obvestilom, da se je čas iztekel in končamo igro
                } else {
                    koncajIgro();
                    obvestiSToastom(getString(R.string.napis_konec_igre));
                }
            }
        };

        // sprožimo zgoraj definirano opravilo
        upravljalnikCasovnika.removeCallbacks(casovnik);
        upravljalnikCasovnika.postDelayed(casovnik, 0);
    }

    private void koncajIgro(){
        baloncek.setEnabled(false); // "deaktiviramo" view s sliko
        baloncek.setOnClickListener(null); // odjavimo poslusalca

        // "sprostimo" opravili, ki smo ju uporabili za štetje časa
        upravljalnikCasovnika.removeCallbacks(casovnik);
        upravljalnikGibanjaBaloncka.removeCallbacks(gibanjeBaloncka);
    }

    private void obvestiSToastom(String obvestilo){
        Context context = getApplicationContext();
        CharSequence text = obvestilo;
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    private void obvestiZAlertom(String obvestilo){
        AlertDialog.Builder builder = new AlertDialog.Builder(mainActivity);
        builder.setMessage(obvestilo)
                .setCancelable(false)
                .setNegativeButton(getResources().getString(R.string.napis_OK),
                        (dialog, id) -> dialog.cancel());
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        menu.add(0, MENU_NOVA_IGRA, 0, getString(R.string.napis_menu_nova_igra)); // dodamo prvo menijsko postavko

        SubMenu menuTezavnost = menu.addSubMenu(0, MENU_TEZAVNOST, 0, getString(R.string.napis_menu_spremeni_tezavnost)); // dodamo menijsko postavko, ki vsebuje podmenije

        menuTezavnost.add(1, MENU_TEZAVNOST_LAHKA, 1, getString(R.string.napis_menu_lahka_tezavnost));
        menuTezavnost.add(1, MENU_TEZAVNOST_SREDNJA, 2, getString(R.string.napis_menu_srednja_tezavnost));
        menuTezavnost.add(1, MENU_TEZAVNOST_TEZKA, 3, getString(R.string.napis_menu_tezka_tezavnost));

        menu.add(0, MENU_IZHOD, 0, getString(R.string.napis_izhod)); // dodamo prvo menijsko postavko

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // switch stavek s testiranjem menijske postavke,ki je bila izbrana
        switch (item.getItemId()) {
            case MENU_NOVA_IGRA:
                koncajIgro();
                zacniIgro();
                return true;

            case MENU_TEZAVNOST_LAHKA:
                koncajIgro();
                tezavnost = 1;
                zacniIgro();
                return true;

            case MENU_TEZAVNOST_SREDNJA:
                koncajIgro();
                tezavnost = 2;
                zacniIgro();
                return true;

            case MENU_TEZAVNOST_TEZKA:
                koncajIgro();
                tezavnost = 3;
                zacniIgro();
                return true;

            case MENU_IZHOD:
                koncajIgro();
                finish(); // zaključi aktivnost
                return true;
        }

        return true;
    }
}