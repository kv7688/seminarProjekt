package si.uni_lj.fe.seminar.igra;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

class VpisIgre{
    private final String vzdevek;
    private final String tezavnost;
    private final String rezultat;
    private final String urlStoritve;
    private final Activity callerActivity;

    public VpisIgre(String vzdevek, int tezavnost, int rezultat, Activity callerActivity) {
        this.vzdevek = vzdevek;
        this.tezavnost = String.valueOf(tezavnost);
        this.rezultat = String.valueOf(rezultat);
        this.callerActivity = callerActivity;

        // ker ta razred ni storitev, moramo do resource-ov dostopati preko klicatelja, ki je storitev
        urlStoritve = callerActivity.getString(R.string.URL_base_storitve) + callerActivity.getString(R.string.URL_rel_vpis_igre);
    }

    public String vpis() {
        ConnectivityManager connMgr = (ConnectivityManager) callerActivity.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo;

        try {
            networkInfo = connMgr.getActiveNetworkInfo();
        }
        catch (Exception e){
            //je v manifestu dovoljenje za uporabo omrezja?
            return callerActivity.getResources().getString(R.string.napaka_omrezje);
        }
        if (networkInfo != null && networkInfo.isConnected()) {
            try {
                int responseCode = connect(vzdevek, tezavnost, rezultat);

                if(responseCode==201){
                    return callerActivity.getResources().getString(R.string.rest_rezultat_dodan);
                }
                else{
                    return callerActivity.getResources().getString(R.string.rest_nepricakovan_odgovor)+" "+responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                return callerActivity.getResources().getString(R.string.napaka_storitev);
            }
        }
        else{
            return callerActivity.getResources().getString(R.string.napaka_omrezje);
        }
    }

    // Given a URL, establishes an HttpUrlConnection and retrieves
    // the content as a InputStream, which it returns as a string.
    private int connect(String vzdevek, String tezavnost, String rezultat) throws IOException {
        URL url = new URL(urlStoritve);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(5000 /* milliseconds */);
        conn.setConnectTimeout(10000 /* milliseconds */);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoInput(true);

        try {
            JSONObject json = new JSONObject();
            json.put("vzdevek", vzdevek);
            json.put("tezavnost", tezavnost);
            json.put("rezultat", rezultat);

            // Starts the query
            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(json.toString());
            writer.flush();
            writer.close();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn.getResponseCode();
    }
}