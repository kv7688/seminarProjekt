<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Igra - Vsi igralci</title>
		<link rel="stylesheet" type="text/css" href="stil.css" />
		<script src="JS/vsiIgralci.js"></script>
	</head>
	<body onload="vsiIgralci();">
		<div class="center">
			<?php include "Meni.html"?>
		
			<table id="tabela">
				<tr>
					<th>Vzdevek</th>
					<th>Ime</th>
					<th>Priimek</th>
					<th>E-mail</th>
				</tr>
			</table>
			<div id="odgovor"></div>
		</div>
	</body>
</html>