<?php
$DEBUG = true;

include("orodja.php"); 			// Vključitev 'orodij'

$zbirka = dbConnect();			//Pridobitev povezave s podatkovno zbirko

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');	// Dovolimo dostop izven trenutne domene (CORS)
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.

switch($_SERVER["REQUEST_METHOD"])			//glede na HTTP metodo izvedemo ustrezno dejanje nad virom
{
	case 'GET':
		if(!empty($_GET["vzdevek"]))
		{
			igre_igralca($_GET["vzdevek"]);
		}
		else
		{
			http_response_code(400);	// Bad Request
		}
		break;
		
	case 'POST':
			dodaj_igro();
		break;
		
	default:
		http_response_code(405);	//Method Not Allowed
		break;
}

mysqli_close($zbirka);					// Sprostimo povezavo z zbirko

function igre_igralca($vzdevek)
{
	global $zbirka;
	$vzdevek=mysqli_escape_string($zbirka, $vzdevek);
	$odgovor=array();
	
	if(igralec_obstaja($vzdevek))
	{
		$poizvedba="SELECT tezavnost, rezultat, casovni_zig FROM odigrana_igra WHERE vzdevek='$vzdevek'";
		
		$result=mysqli_query($zbirka, $poizvedba);

		while($vrstica=mysqli_fetch_assoc($result))
		{
			$odgovor[]=$vrstica;
		}
		
		http_response_code(200);		//OK
		echo json_encode($odgovor);
	}
	else
	{
		http_response_code(404);	// Not Found
	}
}

function dodaj_igro()
{
	global $zbirka, $DEBUG;
	
	$podatki = json_decode(file_get_contents('php://input'), true);
	
	if(isset($podatki["vzdevek"], $podatki["tezavnost"], $podatki["rezultat"]))
	{
		if(igralec_obstaja($podatki["vzdevek"]))	//preprecimo napako zaradi krsitve FK 
		{
			$vzdevek = mysqli_escape_string($zbirka, $podatki["vzdevek"]);
			$tezavnost = mysqli_escape_string($zbirka, $podatki["tezavnost"]);
			$rezultat = mysqli_escape_string($zbirka, $podatki["rezultat"]);
				
			$poizvedba="INSERT INTO odigrana_igra (vzdevek, tezavnost, rezultat) VALUES ('$vzdevek', $tezavnost, $rezultat)";
			
			if(mysqli_query($zbirka, $poizvedba))
			{
				http_response_code(201);	// Created
				// ne pošljemo URL-ja do vpisane igre, ker ne omogočamo vpogleda v posamezno igro
			}
			else
			{
				http_response_code(500);	// Internal Server Error

				if($DEBUG)	//Pozor: vračanje podatkov o napaki na strežniku je varnostno tveganje!
				{
					pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
				}
			}
		}
		else
		{
			http_response_code(409);	// Conflict (in ne 404 - vir na katerega se tu sklicujemo je igra in ne igralec!)
			pripravi_odgovor_napaka("Igralec ne obstaja!", 567);
		}
	}
	else
	{
		http_response_code(400);	// Bad Request
	}
}
?>