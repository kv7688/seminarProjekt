<?php
$DEBUG = true;							// Priprava podrobnejših opisov napak (med testiranjem)

include("orodja.php"); 					// Vključitev 'orodij'

$zbirka = dbConnect();					// Pridobitev povezave s podatkovno zbirko

header('Content-Type: application/json');	// Nastavimo MIME tip vsebine odgovora
header('Access-Control-Allow-Origin: *');	// Dovolimo dostop izven trenutne domene (CORS)
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');		//v preflight poizvedbi za CORS sta privzeto dovoljeni le metodi GET in POST

switch($_SERVER["REQUEST_METHOD"])		// Glede na HTTP metodo v zahtevi izberemo ustrezno dejanje nad virom
{
	case 'GET':
		if(!empty($_GET["vzdevek"]))
		{
			pridobi_igralca($_GET["vzdevek"]);		// Če odjemalec posreduje vzdevek, mu vrnemo podatke izbranega igralca
		}
		else
		{
			pridobi_vse_igralce();					// Če odjemalec ne posreduje vzdevka, mu vrnemo podatke vseh igralcev
		}
		break;
		
	// Dopolnite še z dodajanjem, posodabljanjem in brisanjem igralca
	case 'POST':
		dodaj_igralca();
		break;
		
	case 'PUT':
		if(!empty($_GET["vzdevek"]))
		{
			posodobi_igralca($_GET["vzdevek"]);
		}
		else
		{
			http_response_code(400);	// Če ne posredujemo vzdevka je to 'Bad Request'
		}
		break;
		
	case 'DELETE':
		if(!empty($_GET["vzdevek"]))
		{
			izbrisi_igralca($_GET["vzdevek"]);
		}
		else
		{
			http_response_code(400);	// Bad Request
		}
		break;
		
	case 'OPTIONS':						//Options dodan zaradi pre-fight poizvedbe za CORS (pri uporabi metod PUT in DELETE)
		http_response_code(204);
		break;
		
	default:
		http_response_code(405);		//Če naredimo zahtevo s katero koli drugo metodo je to 'Method Not Allowed'
		break;
}

mysqli_close($zbirka);					// Sprostimo povezavo z zbirko


// ----------- konec skripte, sledijo funkcije -----------

function pridobi_vse_igralce()
{
	global $zbirka;
	$odgovor=array();
	
	$poizvedba="SELECT vzdevek, ime, priimek, email FROM igralec";	
	
	$rezultat=mysqli_query($zbirka, $poizvedba);
	
	while($vrstica=mysqli_fetch_assoc($rezultat))
	{
		$odgovor[]=$vrstica;
	}
	
	http_response_code(200);		//OK
	echo json_encode($odgovor);
}

function pridobi_igralca($vzdevek)
{
	global $zbirka;
	$vzdevek=mysqli_escape_string($zbirka, $vzdevek);
	
	$poizvedba="SELECT vzdevek, ime, priimek, email FROM igralec WHERE vzdevek='$vzdevek'";
	
	$rezultat=mysqli_query($zbirka, $poizvedba);

	if(mysqli_num_rows($rezultat)>0)	//igralec obstaja
	{
		$odgovor=mysqli_fetch_assoc($rezultat);
		
		http_response_code(200);		//OK
		echo json_encode($odgovor);
	}
	else							// igralec ne obstaja
	{
		http_response_code(404);		//Not found
	}
}

function dodaj_igralca()
{
	global $zbirka, $DEBUG;
	
	$podatki = json_decode(file_get_contents('php://input'), true);
	
	if(isset($podatki["vzdevek"], $podatki["geslo"], $podatki["ime"], $podatki["priimek"], $podatki["email"]))
	{
		$vzdevek = mysqli_escape_string($zbirka, $podatki["vzdevek"]);
		$geslo = password_hash(mysqli_escape_string($zbirka, $podatki["geslo"]), PASSWORD_DEFAULT);
		$ime = mysqli_escape_string($zbirka, $podatki["ime"]);
		$priimek = mysqli_escape_string($zbirka, $podatki["priimek"]);
		$email = mysqli_escape_string($zbirka, $podatki["email"]);
			
		if(!igralec_obstaja($vzdevek))
		{	
			$poizvedba="INSERT INTO igralec (vzdevek, geslo, ime, priimek, email) VALUES ('$vzdevek', '$geslo', '$ime', '$priimek', '$email')";
			
			if(mysqli_query($zbirka, $poizvedba))
			{
				http_response_code(201);	// Created
				$odgovor=URL_vira($vzdevek);
				echo json_encode($odgovor);
			}
			else
			{
				http_response_code(500);	// Internal Server Error (ni nujno vedno streznik kriv!)
				
				if($DEBUG)	//Pozor: vračanje podatkov o napaki na strežniku je varnostno tveganje!
				{
					pripravi_odgovor_napaka(mysqli_error($zbirka), 123);
				}
			}
		}
		else
		{
			http_response_code(409);	// Conflict
			pripravi_odgovor_napaka("Igralec že obstaja!", 234);
		}
	}
	else
	{
		http_response_code(400);	// Bad Request
	}
}

function posodobi_igralca($vzdevek)
{
	global $zbirka, $DEBUG;
	
	$vzdevek = mysqli_escape_string($zbirka, $vzdevek);
	
	$podatki = json_decode(file_get_contents("php://input"),true);
		
	if(igralec_obstaja($vzdevek))
	{
		if(isset($podatki["geslo"], $podatki["ime"], $podatki["priimek"], $podatki["email"]))
		{
			$geslo = password_hash(mysqli_escape_string($zbirka, $podatki["geslo"]), PASSWORD_DEFAULT);
			$ime = mysqli_escape_string($zbirka, $podatki["ime"]);
			$priimek = mysqli_escape_string($zbirka, $podatki["priimek"]);
			$email = mysqli_escape_string($zbirka, $podatki["email"]);
			
			$poizvedba = "UPDATE igralec SET geslo='$geslo', ime='$ime', priimek='$priimek', email='$email' WHERE vzdevek='$vzdevek'";
			
			if(mysqli_query($zbirka, $poizvedba))
			{
				http_response_code(204);	//OK with no content
			}
			else
			{
				http_response_code(500);	// Internal Server Error (ni nujno vedno streznik kriv!)
				
				if($DEBUG)	//Pozor: vračanje podatkov o napaki na strežniku je varnostno tveganje!
				{
					pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
				}
			}
		}
		else
		{
			http_response_code(400);	// Bad Request
		}
	}
	else
	{
		http_response_code(404);	// Not Found
	}
}	
	
function izbrisi_igralca($vzdevek)
{	
	global $zbirka, $DEBUG;
	$vzdevek=mysqli_escape_string($zbirka, $vzdevek);

	if(igralec_obstaja($vzdevek))
	{
		$poizvedba="DELETE FROM igralec WHERE vzdevek='$vzdevek'";
		
		if(mysqli_query($zbirka, $poizvedba))
		{
			http_response_code(204);	//OK with no content
		}
		else
		{
			http_response_code(500);	// Internal Server Error (ni nujno vedno streznik kriv!)
			
			if($DEBUG)	//Pozor: vračanje podatkov o napaki na strežniku je varnostno tveganje!
			{
				pripravi_odgovor_napaka(mysqli_error($zbirka), 345);
			}
		}
	}
	else
	{
		http_response_code(404);	// Not Found
	}
}
?>