<?php
$DEBUG = true;							// Priprava podrobnejših opisov napak (med testiranjem)

include("orodja.php"); 					// Vključitev 'orodij'

$zbirka = dbConnect();					// Pridobitev povezave s podatkovno zbirko

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');	// Dovolimo dostop izven trenutne domene (CORS)

switch($_SERVER["REQUEST_METHOD"])			// Glede na HTTP metodo izvedemo ustrezno dejanje nad virom
{
	case 'GET':
		if(!empty($_GET["tezavnost"]))
		{
			lestvica($_GET["tezavnost"]);
		}
		else
		{
			http_response_code(400);	// Bad Request
		}
		break;
	default:
		http_response_code(405);	//Method Not Allowed
		break;
}

function lestvica($tezavnost)
{
	global $zbirka;
	$tezavnost=mysqli_escape_string($zbirka, $tezavnost);
	$odgovor=array();

	$poizvedba="SELECT vzdevek, MAX(rezultat) FROM odigrana_igra WHERE tezavnost='$tezavnost' GROUP BY vzdevek ORDER BY MAX(rezultat) DESC LIMIT 10";
	
	$result=mysqli_query($zbirka, $poizvedba);

	while($vrstica = mysqli_fetch_assoc($result))
	{
		$odgovor[]=$vrstica;
	}
	
	http_response_code(200);		//OK
	echo json_encode($odgovor);
}
?>