<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Igra - Prva stran</title>
		<link rel="stylesheet" type="text/css" href="stil.css" />
	</head>
	<body>
		<div class="center">
			<p>index.php preprečuje brskanje po datotekah spletnega mesta<br/>
			Je tudi primerno mesto, kjer lahko odjemalcem poveste, kako naj uporabijo vaš API.
		 </p>
			<img src="slike/api.png">
		</div>
	</body>
</html>
