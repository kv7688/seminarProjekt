<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Igra - Podatki Igralca</title>
		<link rel="stylesheet" type="text/css" href="stil.css" />
		<script src="JS/igralec.js"></script>
	</head>
	<body>
		<div class="center">
			<?php include "Meni.html"?>
		
			<form id="obrazec" onsubmit="podatkiIgralca(); return false;">
				<label for="vzdevek">Vzdevek:</label>
				<input type="text" name="vzdevek" required />
				<input type="submit" value="Prikaži" />
			</form>
			<br/>
			<form id="posodobitev" onsubmit="posodobiPodatke(); return false;" style="display: none">
				<label for="geslo">Geslo:</label>
				<input type="password" name="geslo" required /><br/>
				
				<label for="ime">Ime:</label>
				<input type="text" name="ime" required /><br/>

				<label for="priimek">Priimek:</label>
				<input type="text" name="priimek" required /><br/>
								
				<label for="email">Email:</label>
				<input type="email" name="email" required /><br/>

				<input type="submit" value="Posodobi" />
			</form>
			<div id="odgovor"></div>
		</div>
	</body>
</html>