package si.uni_lj.fe.seminar.api;

public class ReservationIdRequestBody {
    private int idRezervacija;

    public ReservationIdRequestBody(int idRezervacija) {
        this.idRezervacija = idRezervacija;
    }
}