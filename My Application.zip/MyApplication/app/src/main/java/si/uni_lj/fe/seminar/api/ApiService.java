package si.uni_lj.fe.seminar.api;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import si.uni_lj.fe.seminar.api.reservations.AddReservationRequest;
import si.uni_lj.fe.seminar.api.reservations.Reservation;
import si.uni_lj.fe.seminar.api.reservations.UpdateReservationRequest;
import si.uni_lj.fe.seminar.api.users.LoginRequest;
import si.uni_lj.fe.seminar.api.users.User;

public interface ApiService {
    @GET("rezervacija/{id}")
    Call<List<Reservation>> getReservations(@Path("id") int userId);

    @POST("rezervacija")
    Call<Void> createReservation(@Body AddReservationRequest request);

    @PUT("rezervacija/{id}")
    Call<Void> updateReservation(@Path("id") int userId, @Body UpdateReservationRequest request);

    @POST("prijava.php")
    Call<User> login(@Body LoginRequest request);
}