package si.uni_lj.fe.seminar;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.app.DatePickerDialog;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import si.uni_lj.fe.seminar.api.ApiService;
import si.uni_lj.fe.seminar.api.RetrofitClient;
import si.uni_lj.fe.seminar.api.reservations.AddReservationRequest;
import si.uni_lj.fe.seminar.api.reservations.Reservation;
import si.uni_lj.fe.seminar.api.reservations.ReservationAdapter;
import si.uni_lj.fe.seminar.api.reservations.UpdateReservationRequest;
import si.uni_lj.fe.seminar.api.users.LoginRequest;
import si.uni_lj.fe.seminar.api.users.User;


public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerViewReservationDetails;
    private ReservationAdapter reservationDetailsAdapter;

    MenuItem rezervacijeMenuItem, novaMenuItem, spremeniMenuItem, izbrisiMenuItem, odjavaMenuItem;

    private int currentlyLoggedUserId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        currentlyLoggedUserId = -1;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewReservationDetails = findViewById(R.id.recyclerViewReservationDetails);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        rezervacijeMenuItem = menu.findItem(R.id.meni_rezervacije);
        novaMenuItem = menu.findItem(R.id.meni_nova);
        spremeniMenuItem = menu.findItem(R.id.meni_sprmeni);
        izbrisiMenuItem = menu.findItem(R.id.meni_izbrisi);
        odjavaMenuItem = menu.findItem(R.id.meni_odjava);

        // Check if the user is logged in (currentlyLoggedUserId is not -1)
        if (currentlyLoggedUserId == -1) {
            rezervacijeMenuItem.setVisible(false);
            novaMenuItem.setVisible(false);
            spremeniMenuItem.setVisible(false);
            odjavaMenuItem.setVisible(false);
            izbrisiMenuItem.setVisible(true);
        } else {
            rezervacijeMenuItem.setVisible(true);
            novaMenuItem.setVisible(true);
            spremeniMenuItem.setVisible(true);
            odjavaMenuItem.setVisible(true);
            izbrisiMenuItem.setVisible(false);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.meni_domov) {
            Toast.makeText(this, "Domov izbrano", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.meni_rezervacije) {
            recyclerViewReservationDetails.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Moje rezervacije izbrano", Toast.LENGTH_SHORT).show();
            checkApiReachability();
            return true;
        } else if (id == R.id.meni_nova) {
            try{
                recyclerViewReservationDetails.setVisibility(View.GONE);
            } catch(Exception e) {
                // ignore
            }
            prikaziDialogZaDodajanjeRezervacije();
            return true;
        } else if (id == R.id.meni_sprmeni) {
            try{
                recyclerViewReservationDetails.setVisibility(View.GONE);
            } catch(Exception e) {
                // ignore
            }
            prikaziDialogZaSpreminjanjeRezervacije();
            return true;
        } else if (id == R.id.meni_izbrisi) {
            try{
                recyclerViewReservationDetails.setVisibility(View.GONE);
            } catch(Exception e) {
                // ignore
            }
            prikaziDialogZaPrijavo();
            return true;
        } else if (id == R.id.meni_odjava) {
            try{
                recyclerViewReservationDetails.setVisibility(View.GONE);
            } catch(Exception e) {
                // ignore
            }
            izbrisiMenuItem.setVisible(true);
            rezervacijeMenuItem.setVisible(false);
            novaMenuItem.setVisible(false);
            spremeniMenuItem.setVisible(false);
            odjavaMenuItem.setVisible(false);
            currentlyLoggedUserId = -1;
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void prikaziDialogZaPrijavo() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_prijava, null);
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setView(dialogView);

        final EditText editTextEmail = dialogView.findViewById(R.id.editTextEmail);
        final EditText editTextPassword = dialogView.findViewById(R.id.editTextPassword);

        dialogBuilder.setPositiveButton("Prijava", (dialog, which) -> {
            String email = editTextEmail.getText().toString();
            String password = editTextPassword.getText().toString();

            // Tukaj lahko implementiraš dejansko logiko za prijavo
            LoginHandler(email, password);

            Toast.makeText(MainActivity.this, "Prijava uspešna. ", Toast.LENGTH_SHORT).show();

            rezervacijeMenuItem.setVisible(true);
            novaMenuItem.setVisible(true);
            spremeniMenuItem.setVisible(true);
            odjavaMenuItem.setVisible(true);
            izbrisiMenuItem.setVisible(false);
        });

        dialogBuilder.setNegativeButton("Prekliči", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
    }

    private void prikaziDialogZaDodajanjeRezervacije() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_novarezervacija, null);
        dialogBuilder.setView(dialogView);

        Spinner spinnerApartma = dialogView.findViewById(R.id.spinnerApartma);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.apartmaji, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerApartma.setAdapter(adapter);

        final EditText editTextDatumPrihoda = dialogView.findViewById(R.id.editTextDatumPrihoda);
        final EditText editTextDatumOdhoda = dialogView.findViewById(R.id.editTextDatumOdhoda);

        editTextDatumPrihoda.setOnClickListener(v -> pokaziDatePickerDialog(editTextDatumPrihoda));
        editTextDatumOdhoda.setOnClickListener(v -> pokaziDatePickerDialog(editTextDatumOdhoda));

        dialogBuilder.setPositiveButton("Dodaj", (dialog, which) -> {
            String apartma = spinnerApartma.getSelectedItem().toString();
            String datumPrihoda = editTextDatumPrihoda.getText().toString();
            String datumOdhoda = editTextDatumOdhoda.getText().toString();

            // Tukaj lahko implementiraš logiko za shranjevanje ali obdelavo teh podatkov
            int apartmaId = -1;
            if (apartma.equals("Oljka")) {
                apartmaId = 1;
            }
            if (apartma.equals("Sonček")) {
                apartmaId = 2;
            }
            if (apartma.equals("Morje")) {
                apartmaId = 3;
            }
            if (apartma.equals("Barka")) {
                apartmaId = 4;
            }

            AddNewReservationHandler(apartmaId, datumPrihoda, datumOdhoda);

            Toast.makeText(MainActivity.this, "Rezervacija dodana: " + apartma + ", " + datumPrihoda + " do " + datumOdhoda, Toast.LENGTH_SHORT).show();
        });

        dialogBuilder.setNegativeButton("Prekliči", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
    }


        private void prikaziDialogZaSpreminjanjeRezervacije() {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
            LayoutInflater inflater = this.getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_spremenirezervacijo, null); // Predpostavimo, da uporabljamo isti layout, dodamo EditText za ID
            dialogBuilder.setView(dialogView);

            Spinner spinnerApartma = dialogView.findViewById(R.id.spinnerApartma);
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.apartmaji, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerApartma.setAdapter(adapter);

            final EditText editTextDatumPrihoda = dialogView.findViewById(R.id.editTextDatumPrihoda);
            final EditText editTextDatumOdhoda = dialogView.findViewById(R.id.editTextDatumOdhoda);

            editTextDatumPrihoda.setOnClickListener(v -> pokaziDatePickerDialog(editTextDatumPrihoda));
            editTextDatumOdhoda.setOnClickListener(v -> pokaziDatePickerDialog(editTextDatumOdhoda));

            final EditText editTextRezervacijaId = dialogView.findViewById(R.id.editTextRezervacijaId); // Prepričajte se, da dodate to polje v layout


            editTextDatumPrihoda.setOnClickListener(v -> pokaziDatePickerDialog(editTextDatumPrihoda));
            editTextDatumOdhoda.setOnClickListener(v -> pokaziDatePickerDialog(editTextDatumOdhoda));

            dialogBuilder.setPositiveButton("Spremeni", (dialog, which) -> {
                String idRezervacije = editTextRezervacijaId.getText().toString();
                String apartma = spinnerApartma.getSelectedItem().toString();
                String datumPrihoda = editTextDatumPrihoda.getText().toString();
                String datumOdhoda = editTextDatumOdhoda.getText().toString();

                // Tukaj lahko implementiraš logiko za shranjevanje ali obdelavo teh podatkov
                int apartmaId = -1;
                if (apartma.equals("Oljka")) {
                    apartmaId = 1;
                }
                if (apartma.equals("Sonček")) {
                    apartmaId = 2;
                }
                if (apartma.equals("Morje")) {
                    apartmaId = 3;
                }
                if (apartma.equals("Barka")) {
                    apartmaId = 4;
                }

                UpdateReservationHandler(Integer.parseInt(idRezervacije), apartmaId, datumPrihoda, datumOdhoda);

                Toast.makeText(MainActivity.this, "Rezervacija spremenjena: " + idRezervacije + ", " + apartma + ", " + datumPrihoda + " do " + datumOdhoda, Toast.LENGTH_SHORT).show();
            });

            dialogBuilder.setNegativeButton("Prekliči", (dialog, which) -> dialog.dismiss());

            AlertDialog dialog = dialogBuilder.create();
            dialog.show();
        }



    private void pokaziDatePickerDialog(final EditText editText) {
        final Calendar c = Calendar.getInstance();
        int leto = c.get(Calendar.YEAR);
        int mesec = c.get(Calendar.MONTH);
        int dan = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, monthOfYear, dayOfMonth) -> editText.setText(String.format("%d-%02d-%02d", year, monthOfYear + 1, dayOfMonth)),
                leto, mesec, dan);
        datePickerDialog.show();
    }

    private void ShowMyReservations() {
        System.out.println("SHOW MY RESERVATIONS - method - USER ID: " + currentlyLoggedUserId);
        ApiService apiService = RetrofitClient.getApiService();

        Call<List<Reservation>> call = apiService.getReservations(currentlyLoggedUserId);
        call.enqueue(new Callback<List<Reservation>>() {
            @Override
            public void onResponse(Call<List<Reservation>> call, Response<List<Reservation>> response) {
                if (response.isSuccessful()) {
                    List<Reservation> reservations = response.body();
                    updateAdapterReservationDetails(reservations);
                    // Handle the reservations
                } else {
                    // Handle the error
                }
            }

            @Override
            public void onFailure(Call<List<Reservation>> call, Throwable t) {
                // Handle the failure
            }
        });
    }

    private void AddNewReservation(int apartmaId, String datumPrihoda, String datumOdhoda) {
        ApiService apiService = RetrofitClient.getApiService();

        AddReservationRequest reservationRequest = new AddReservationRequest(datumPrihoda, datumOdhoda, apartmaId, currentlyLoggedUserId);

        Call<Void> call = apiService.createReservation(reservationRequest);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // do nothing, be happy
                } else {
                    // Handle the error
                    Toast.makeText(MainActivity.this, "Error creating reservation", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // Handle the failure
                Toast.makeText(MainActivity.this, "Failed to create reservation", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void Login(String email, String password) {
        ApiService apiService = RetrofitClient.getApiService();

        LoginRequest loginRequest = new LoginRequest(email, password);

        Call<User> call = apiService.login(loginRequest);

        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful()) {
                    User user = response.body();
                    currentlyLoggedUserId = user.getUserId();
                } else {
                    // Handle the error
                    Toast.makeText(MainActivity.this, "Error logging in.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                // Handle the failure
                Toast.makeText(MainActivity.this, "Failed to login.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void UpdateReservation(int rezervacijaId, int apartmaId, String datumPrihoda, String datumOdhoda) {
        ApiService apiService = RetrofitClient.getApiService();

        UpdateReservationRequest reservationRequest = new UpdateReservationRequest(datumPrihoda, datumOdhoda, apartmaId, rezervacijaId);

        Call<Void> call = apiService.updateReservation(currentlyLoggedUserId, reservationRequest);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // do nothing, be happy
                } else {
                    // Handle the error
                    Toast.makeText(MainActivity.this, "Error updating reservation", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // Handle the failure
                Toast.makeText(MainActivity.this, "Failed to update reservation", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkApiReachability() {
        recyclerViewReservationDetails.setHasFixedSize(true);

        // Set up RecyclerView with an empty list initially
        reservationDetailsAdapter = new ReservationAdapter(new ArrayList<>());
        recyclerViewReservationDetails.setAdapter(reservationDetailsAdapter);

        // Call your method to fetch reservations and update the adapter
        // ShowMyReservations();

        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean isReachable = true;

                // Use a Handler to post the result back to the main thread
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (isReachable) {
                            Thread thread = new Thread(new Runnable() {

                                @Override
                                public void run() {
                                    try {
                                        ShowMyReservations();
                                        // isApiReachable();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });

                            thread.start();
                        } else {
                            // Handle the case where the API is not reachable
                            // Display an error message or take appropriate action
                        }
                    }
                });
            }
        }).start();
    }

    private void LoginHandler(String email, String password) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Thread thread = new Thread(new Runnable() {

                            @Override
                            public void run() {
                                try {
                                    Login(email, password);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                        thread.start();
                    }
                });
            }
        }).start();
    }

    private void AddNewReservationHandler(int apartmaId, String datumPrihoda, String datumOdhoda) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Thread thread = new Thread(new Runnable() {

                            @Override
                            public void run() {
                                try {
                                    AddNewReservation(apartmaId, datumPrihoda, datumOdhoda);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                        thread.start();
                    }
                });
            }
        }).start();
    }

    private void UpdateReservationHandler(int rezervacijaId, int apartmaId, String datumPrihoda, String datumOdhoda) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Thread thread = new Thread(new Runnable() {

                            @Override
                            public void run() {
                                try {
                                    UpdateReservation(rezervacijaId, apartmaId, datumPrihoda, datumOdhoda);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                        thread.start();
                    }
                });
            }
        }).start();
    }

    // Update the adapter with the list of reservations
    private void updateAdapterReservationDetails(List<Reservation> reservations) {
        reservationDetailsAdapter = new ReservationAdapter(reservations);
        recyclerViewReservationDetails.setAdapter(reservationDetailsAdapter);
    }
}




