package si.uni_lj.fe.seminar.api.reservations;

public class UpdateReservationRequest {
    private String datumPrihoda;
    private String datumOdhoda;
    private int idApartma;
    private int idRezervacija;

    public UpdateReservationRequest(String datumPrihoda, String datumOdhoda, int idApartma, int idRezervacija) {
        this.datumPrihoda = datumPrihoda;
        this.datumOdhoda = datumOdhoda;
        this.idApartma = idApartma;
        this.idRezervacija = idRezervacija;
    }

    public String getDatumPrihoda() {
        return datumPrihoda;
    }

    public void setDatumPrihoda(String datumPrihoda) {
        this.datumPrihoda = datumPrihoda;
    }

    public String getDatumOdhoda() {
        return datumOdhoda;
    }

    public void setDatumOdhoda(String datumOdhoda) {
        this.datumOdhoda = datumOdhoda;
    }

    public int getApartmaId() {
        return idApartma;
    }

    public void setApartmaId(int apartmaId) {
        this.idApartma = apartmaId;
    }

    public int getRezervacijaId() {
        return idRezervacija;
    }

    public void setRezervacijaId(int idRezervacija) {
        this.idRezervacija = idRezervacija;
    }
}
