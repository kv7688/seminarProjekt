package si.uni_lj.fe.seminar.api.reservations;

public class AddReservationRequest {
    private String datumPrihoda;
    private String datumOdhoda;
    private int idApartma;
    private int idUporabnik;

    public AddReservationRequest(String datumPrihoda, String datumOdhoda, int idApartma, int idUporabnik) {
        this.datumPrihoda = datumPrihoda;
        this.datumOdhoda = datumOdhoda;
        this.idApartma = idApartma;
        this.idUporabnik = idUporabnik;
    }

    public String getDatumPrihoda() {
        return datumPrihoda;
    }

    public void setDatumPrihoda(String datumPrihoda) {
        this.datumPrihoda = datumPrihoda;
    }

    public String getDatumOdhoda() {
        return datumOdhoda;
    }

    public void setDatumOdhoda(String datumOdhoda) {
        this.datumOdhoda = datumOdhoda;
    }

    public int getApartmaId() {
        return idApartma;
    }

    public void setApartmaId(int apartmaId) {
        this.idApartma = apartmaId;
    }

    public int getUserId() {
        return idUporabnik;
    }

    public void setUserId(int userId) {
        this.idUporabnik = userId;
    }
}
