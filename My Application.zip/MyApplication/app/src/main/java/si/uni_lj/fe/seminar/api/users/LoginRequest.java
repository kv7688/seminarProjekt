package si.uni_lj.fe.seminar.api.users;


public class LoginRequest {
    private String Email;
    private String Geslo;

    public LoginRequest(String email, String geslo) {
        Email = email;
        Geslo = geslo;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getGeslo() {
        return Geslo;
    }

    public void setGeslo(String geslo) {
        Geslo = geslo;
    }
}
