package si.uni_lj.fe.seminar.api.reservations;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

public class Reservation {
    @SerializedName("ID")
    private String ID;

    @SerializedName("idApartma")
    private String idApartma;

    @SerializedName("datumPrihoda")
    private String datumPrihoda;

    @SerializedName("datumOdhoda")
    private String datumOdhoda;

    @SerializedName("idUporabnik")
    private String idUporabnik;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getIdApartma() {
        return idApartma;
    }

    public void setIdApartma(String idApartma) {
        this.idApartma = idApartma;
    }

    public String getDatumPrihoda() {
        return datumPrihoda;
    }

    public void setDatumPrihoda(String datumPrihoda) {
        this.datumPrihoda = datumPrihoda;
    }

    public String getDatumOdhoda() {
        return datumOdhoda;
    }

    public void setDatumOdhoda(String datumOdhoda) {
        this.datumOdhoda = datumOdhoda;
    }

    public String getIdUporabnik() {
        return idUporabnik;
    }

    public void setIdUporabnik(String idUporabnik) {
        this.idUporabnik = idUporabnik;
    }
}
