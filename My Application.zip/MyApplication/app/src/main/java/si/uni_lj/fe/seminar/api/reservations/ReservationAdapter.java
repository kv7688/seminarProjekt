package si.uni_lj.fe.seminar.api.reservations;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.List;

import si.uni_lj.fe.seminar.R;

// ReservationAdapter.java
public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ReservationViewHolder> {
    private List<Reservation> reservations;

    public ReservationAdapter(List<Reservation> reservations) {
        this.reservations = reservations;
    }

    @NonNull
    @Override
    public ReservationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reservation, parent, false);
        return new ReservationViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ReservationViewHolder holder, int position) {
        Reservation reservation = reservations.get(position);
        // Bind reservation data to UI elements in the ViewHolder
        holder.detailsID.setText("ID rezervacije: " + reservation.getID());
        holder.detailsDatumPrihoda.setText("Datum prihoda: " + reservation.getDatumPrihoda());
        holder.detailsDatumOdhoda.setText("Datum odhoda: " + reservation.getDatumOdhoda());
        holder.detailsIdApartma.setText("ID apartma: " + reservation.getIdApartma());
        holder.detailsIdUporabnik.setText("ID uporabnik: " + reservation.getIdUporabnik());

        // Add more bindings as needed
    }

    @Override
    public int getItemCount() {
        return reservations.size();
    }

    static class ReservationViewHolder extends RecyclerView.ViewHolder {
        TextView detailsID, detailsDatumPrihoda, detailsDatumOdhoda, detailsIdApartma, detailsIdUporabnik;

        ReservationViewHolder(@NonNull View itemView) {
            super(itemView);
            detailsID = itemView.findViewById(R.id.detailsID);
            detailsDatumPrihoda = itemView.findViewById(R.id.detailsDatumPrihoda);
            detailsDatumOdhoda = itemView.findViewById(R.id.detailsDatumOdhoda);
            detailsIdApartma = itemView.findViewById(R.id.detailsIdApartma);
            detailsIdUporabnik = itemView.findViewById(R.id.detailsIdUporabnik);
        }
    }
}