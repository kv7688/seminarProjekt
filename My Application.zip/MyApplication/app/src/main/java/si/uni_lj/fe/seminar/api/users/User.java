package si.uni_lj.fe.seminar.api.users;

import com.google.gson.annotations.SerializedName;

public class User {

    @SerializedName("jwt")
    private String jwt;

    @SerializedName("userId")
    private int userId;

    public String getJwt() {
        return jwt;
    }

    public void setJwt(String jwt) {
        this.jwt = jwt;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
